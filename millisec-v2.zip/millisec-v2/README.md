# MilliSec Layihəsi v2

## İstifadəçilər
| E-poçt | Şifrə | Rol |
|---|---|---|
| admin@millisec.live | Admin123! | admin |
| john@millisec.live | User123! | user |
| sarah@millisec.live | Sarah123! | staff |

## Qaldırmaq
```bash
cp .env.example .env
# .env faylında şifrələri doldur
docker compose up -d --build
```

## DNS Ayarları (millisec.live domenin üçün)
| Tip | Ad | Dəyər |
|---|---|---|
| A | @ | SERVER_IP |
| A | www | SERVER_IP |
| A | intranet | SERVER_IP |
